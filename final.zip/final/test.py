import sys
import os
import time
from PyQt5 import uic, QtWidgets
import glob
import shutil
import os.path
from os import path
import xml.etree.ElementTree as ET
import csv
import openpyxl
import json
import xmltodict
import pandas as pd
from pandas.io.json import json_normalize
from bs4 import BeautifulSoup
import win32com.client as win32

parent_path = ''
test = ''
uipath = ''
text = []
testing = []
Folder_name = ''
f = ''
state = []

for root, dirs, files in os.walk("."):
    for f in files:
        if f.endswith(".ui"):
            uipath = os.path.relpath(os.path.join(root, f), ".")

qtCreatorFile = uipath

Ui_MainWindow, QtBaseClass = uic.loadUiType(qtCreatorFile)

class MyApp(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.height = 330
        self.width = 660
        self.top = 150
        self.left = 350
        self.title = "XML TO EXCEL CONVERSION"
        self.setupUi(self)
        self.browse.clicked.connect(self.selectInputFolder)
        self.exportFile.clicked.connect(self.ImportExport)
        self.quit.clicked.connect(self.closes)
        
    def selectInputFolder(self):
        global testing
        global testings
        global test
        global text
        global parent_path
        global street
        global city
        global scode
        global pcode
        global file_name_path
        global state
        
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        options = QtWidgets.QFileDialog.Options()
        options |= QtWidgets.QFileDialog.DontUseNativeDialog
        parent_path = str(QtWidgets.QFileDialog.getExistingDirectory(self, "Select Directory"))
        
        if parent_path:
            if os.sep=='\\':
                parent_path=parent_path.replace('/', '\\')
                return parent_path
            else:
                return ""    
                
    def ImportExport(self):
        output = os.path.join(os.getcwd(), "output")
        if not os.path.exists(output):
            os.makedirs(output)

        for dirs in os.listdir(parent_path):
            dir_name = dirs
            dir_pathss = os.path.join(parent_path, dirs)
           
            i = 1

            for File in os.listdir(parent_path):
                if File.endswith(".xml"):
                    fname = os.path.splitext(os.path.basename(File))[0]
                    fnames = os.path.splitext(os.path.basename(File))
                    fileName = os.path.basename(File)
                    file_name_path = os.path.join(parent_path, fileName)
                testing.append(file_name_path)
                                       
        testings = list(dict.fromkeys(testing))
        
        for filing in testings:
            filingName = os.path.splitext(os.path.basename(filing))[0] 
            xmlfile = os.path.basename(filing)           
            xlsx_path = os.path.join(output, filingName + '.xlsx')
            csv_paths = os.path.join(output, filingName + '.csv')
            sheetname = "sheet1"
            
            xmlfilepath = os.path.join(parent_path, xmlfile)
            print("Path : ", xmlfilepath)

            soup = BeautifulSoup(open(xmlfilepath, 'r'), 'xml')
            
            state = []

            for resident in soup.find_all('Resident'):
                d = {
                    'Id': resident.get('Id'),
                    'Name': resident.Name.string,
                    'PhoneNumber': resident.PhoneNumber.string,
                    'EmailAddress': resident.EmailAddress.string,
                    'StreetLine': resident.Address.StreetLine.string,
                    'City': resident.Address.City.string,
                    'StateCode': resident.Address.StateCode.string,
                    'PostalCode': resident.Address.PostalCode.string
                }   
                state.append(d)
        
        df = pd.json_normalize(state)
        df.to_excel(xlsx_path,index=False,sheet_name=sheetname,encoding='utf-8')
        
        excel = win32.gencache.EnsureDispatch('Excel.Application') 
        wb = excel.Workbooks.Open(xlsx_path)
        ws = wb.Worksheets(sheetname)
        ws.Columns.AutoFit()
        wb.Save()
        excel.Application.Quit()        
                
        choice = QtWidgets.QMessageBox.information(self, 'Task', 'Completed', QtWidgets.QMessageBox.Ok)
        if choice == QtWidgets.QMessageBox.Ok:
            sys.exit()

    def closes(self):
        choice = QtWidgets.QMessageBox.question(self, 'Export', 'Stop', QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        if choice == QtWidgets.QMessageBox.Yes:
            sys.exit()    
        else:
            pass

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec_())    
        
        
        
        
        
        
        
        
        
        
        